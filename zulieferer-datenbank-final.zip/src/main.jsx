import React from 'react'
import ReactDOM from 'react-dom/client'

const App = () => <div>Zulieferer-Datenbank läuft!</div>

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
